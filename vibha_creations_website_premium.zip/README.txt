VIBHA'S CREATIONS — WEBSITE

Open index.html in Chrome or Edge.

Included:
- Premium responsive design
- Home, Services, Gallery, About, Why Us and Contact
- Quick enquiry form that opens the visitor's email app
- Contact email: vibhacreations777@gmail.com
- Bhavnagar location
- Ladies-only tailoring messaging
- 24+ years experience and 50,000+ orders fulfilled
- Same-day delivery information for 1 dress
- Bulk-order advance notice information

No phone number or social-media account was invented; those can be added later.
